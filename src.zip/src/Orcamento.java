class Orcamento {

    int valor;

    public Orcamento(int valor) {
        this.valor = valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }
}
